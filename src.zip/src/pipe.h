/*********************************************
 *  pipe.h
 *  Socket Interface for Text-Based Adventure Game
 *  COMP3411 Artificial Intelligence
 *  UNSW Session 1, 2016
*/

int tcpopen(char *host, int port);
